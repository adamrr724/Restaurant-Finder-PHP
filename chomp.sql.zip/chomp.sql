--
-- Database: `chomp`
--
CREATE DATABASE IF NOT EXISTS `chomp` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `chomp`;

-- --------------------------------------------------------

--
-- Table structure for table `cuisine`
--

CREATE TABLE `cuisine` (
  `name` text,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cuisine`
--

INSERT INTO `cuisine` (`name`, `id`) VALUES
('Vietnamese', 13),
('Ethiopian', 14),
('German', 15),
('Bar', 16),
('Ice Cream', 18);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rest_name` text,
  `id` bigint(20) UNSIGNED NOT NULL,
  `location` text,
  `price_range` text,
  `cuisine_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `reviewer_name` varchar(255) DEFAULT NULL,
  `review_score` int(11) DEFAULT NULL,
  `review_content` text,
  `restaurant_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `reviewer_name`, `review_score`, `review_content`, `restaurant_id`) VALUES
(1, 'hello', 2, 'badd!!!!', 5),
(2, 'Mary', 5, 'SO GOOD', 5),
(3, 'Paul', 5, 'So cheap and such good sushi!', 10),
(4, 'Cooldude123', 4, 'Awesome Food, servers are awesome!', 10),
(5, 'Mary', 5, 'THIS PLACE IS COOL!', 12),
(6, 'MARY', 3, 'asdf', 12),
(7, 'MARY', 3, 'asdf', 12),
(8, 'Mary', 3, 'The food here was great!', 9),
(9, 'Adam', 1, 'Ew', 9),
(10, 'Ada', 1, 'ewfwef', 27),
(11, 'asdfasd', 2, 'dfsadf', 27),
(12, 'rgeg', 3, 'sgSDvs', 27);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuisine`
--
ALTER TABLE `cuisine`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rest_id` (`id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuisine`
--
ALTER TABLE `cuisine`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
